﻿namespace MasterInjection
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Reflection;

    public class MyServiceProvider : IMyServiceProvider
    {
        public MyServiceProvider()
        {
        }

        public void Add<TSource, TDestination>()
            where TDestination : TSource
        {
            var assembly = Assembly.GetCallingAssembly();
            var interfaces = assembly.GetTypes().Where(x => x.IsInterface);
            
            foreach (var currentInterface in interfaces)
            {
                var implType = assembly.GetTypes().FirstOrDefault(x => currentInterface.IsAssignableFrom(x));
                
                CreateInstance(implType);
            }
        }

        public object CreateInstance(Type type)
        {
            //var path = Assembly.GetAssembly(type).Location;
            //var assembly = Assembly.LoadFrom(path);
            //var obj = assembly.CreateInstance(type.FullName);
            return Activator.CreateInstance(type);
            //var test = type.GetConstructors();
            //foreach (var constructorInfo in test)
            //{
            //    var arg = constructorInfo.GetGenericArguments();
            //}
            //var obj = Activator.CreateInstance(type);
            //return obj;
        }

        public T CreateInstance<T>()
        {
            //T obj = (T)CreateInstance(typeof(T));

            //return obj;
            return Activator.CreateInstance<T>();
        }
    }
}
