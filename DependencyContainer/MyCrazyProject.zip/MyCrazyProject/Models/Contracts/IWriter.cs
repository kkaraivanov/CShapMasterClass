﻿namespace MyCrazyProject.Models.Contracts
{
    public interface IWriter
    {
        void Write(string content);
    }
}
